package project1;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import org.junit.jupiter.api.Test;

public class Project1Test {

    @Test
    public void testMergeSort() {
        int[] arr = {5, 3, 8, 1, 2};
        int[] expected = {1, 2, 3, 5, 8};

        project1.mergeSort(arr);

        assertArrayEquals(expected, arr);
    }

    @Test
    public void testQuickSort() {
        int[] arr = {5, 3, 8, 1, 2};
        int[] expected = {1, 2, 3, 5, 8};

        project1.quickSort(arr, 0, arr.length - 1);

        assertArrayEquals(expected, arr);
    }

    @Test
    public void testHeapSort() {
        int[] arr = {5, 3, 8, 1, 2};
        int[] expected = {1, 2, 3, 5, 8};

        project1.heapSort(arr);

        assertArrayEquals(expected, arr);
    }

    @Test
    public void testShakerSort() {
        int[] arr = {5, 3, 8, 1, 2};
        int[] expected = {1, 2, 3, 5, 8};

        project1.shakerSort(arr);

        assertArrayEquals(expected, arr);
    }
}