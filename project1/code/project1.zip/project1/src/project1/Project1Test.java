package project1;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import org.junit.jupiter.api.Test;

public class Project1Test {

    @Test
    public void testMergeSortSmall() {
        int[] arr = {5, 3, 8, 1, 2};
        int[] expected = {1, 2, 3, 5, 8};

        project1.mergeSort(arr);

        assertArrayEquals(expected, arr);
    }
    
    @Test
    public void testMergeSortLarge() {
        int[] arr = {100, 15, 2, 3, 99, 45, 66, 12, 11, 78, 101, 55, 23, 687, 498, 12, 456, 123, 321, 49, 9, 45, 741, 111, 109};
        int[] expected = {2, 3, 9, 11, 12, 12, 15, 23, 45, 45, 49, 55, 66, 78, 99, 100, 101, 109, 111, 123, 321, 456, 498, 687, 741};

        project1.mergeSort(arr);

        assertArrayEquals(expected, arr);
    }
    

    @Test
    public void testQuickSortSmall() {
        int[] arr = {5, 3, 8, 1, 2};
        int[] expected = {1, 2, 3, 5, 8};

        project1.quickSort(arr, 0, arr.length - 1);

        assertArrayEquals(expected, arr);
    }
    
    @Test
    public void testQuickSortLarge() {
    	int[] arr = {100, 15, 2, 3, 99, 45, 66, 12, 11, 78, 101, 55, 23, 687, 498, 12, 456, 123, 321, 49, 9, 45, 741, 111, 109};
        int[] expected = {2, 3, 9, 11, 12, 12, 15, 23, 45, 45, 49, 55, 66, 78, 99, 100, 101, 109, 111, 123, 321, 456, 498, 687, 741};

        project1.quickSort(arr, 0, arr.length - 1);

        assertArrayEquals(expected, arr);
    }


    @Test
    public void testHeapSortSmall() {
        int[] arr = {5, 3, 8, 1, 2};
        int[] expected = {1, 2, 3, 5, 8};

        project1.heapSort(arr);

        assertArrayEquals(expected, arr);
    }

    @Test
    public void testHeapSortLarge() {
    	int[] arr = {100, 15, 2, 3, 99, 45, 66, 12, 11, 78, 101, 55, 23, 687, 498, 12, 456, 123, 321, 49, 9, 45, 741, 111, 109};
        int[] expected = {2, 3, 9, 11, 12, 12, 15, 23, 45, 45, 49, 55, 66, 78, 99, 100, 101, 109, 111, 123, 321, 456, 498, 687, 741};

        project1.heapSort(arr);

        assertArrayEquals(expected, arr);
    }
    
    @Test
    public void testShakerSortSmall() {
        int[] arr = {5, 3, 8, 1, 2};
        int[] expected = {1, 2, 3, 5, 8};

        project1.shakerSort(arr);

        assertArrayEquals(expected, arr);
    }
    
    @Test
    public void testShakerSortLarge() {
    	int[] arr = {100, 15, 2, 3, 99, 45, 66, 12, 11, 78, 101, 55, 23, 687, 498, 12, 456, 123, 321, 49, 9, 45, 741, 111, 109};
        int[] expected = {2, 3, 9, 11, 12, 12, 15, 23, 45, 45, 49, 55, 66, 78, 99, 100, 101, 109, 111, 123, 321, 456, 498, 687, 741};

        project1.shakerSort(arr);

        assertArrayEquals(expected, arr);
    }
    
    
}