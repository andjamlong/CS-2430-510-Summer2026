package project1;
import java.util.Random;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class project1 {
	
	//create var to track # of comp of each sort
	  private static long mergeComparisons = 0;
	  private static long quickComparisons = 0;
	  private static long heapComparisons = 0;
	  private static long shakerComparisons = 0;
	  
	
	/**
	 * Assist in the creation an arrays with random integers of n size
	 * 
	 * @param n - the requested size of array
	 * @return - an array of n size of randomly generated integers
	 */
	public static int[] generateRandomArray(int n) {
		Random rand = new Random();
		int [] arr = new int[n];
		
		for (int i=0; i < n; i++) {
			arr[i] = rand.nextInt(1000);			
		}
		
		return arr;
	}
	
	/**
	 * Prints all elements of requested array
	 * 
	 * @param arr
	 */
	public static void printArray(int[] arr) {
		for (int num: arr) {
			System.out.print(num + " ");
		}
		System.out.println();		
	}
	
	/**
	 * makes copies of my original array so I can do multiple sorts on it
	 * @param arr
	 * @return
	 */
	private static int[] copy(int[] arr) {
	    return arr.clone();
	}

	
// MERGE SORT	
	/**
	 * mergeSort pt1
	 * In this function we are going to recursively split the desired array until we are presented
	 * with individual elements
	 * 
	 * @param inputArray - array to be sorted
	 */
	public static void mergeSort(int[] inputArray) {
		int inputLength = inputArray.length;
		
		//have we divided all elements of the array already?
		if (inputLength < 2 ) {
			return;
		}
		
		//find the array midpoint, and use that to create two new arrays split at the midpoint
		int midIndex = inputLength / 2;
		int[] leftHalf = new int[midIndex];
		int[] rightHalf = new int[inputLength - midIndex];
		
		//create left array
		for (int i = 0; i < midIndex; i++) {
			leftHalf[i] = inputArray[i];
		}
		
		//create right array
		for (int i = midIndex; i < inputLength; i++) {
			rightHalf[i-midIndex] = inputArray[i];
		}
		
		//call mergeSort recursively on each half array until they are isolated elements
		mergeSort(leftHalf);
		mergeSort(rightHalf);
		
		merge(inputArray, leftHalf, rightHalf);

	}
	
	/**
	 * MergeSort pt2
	 * We are going to take the split arrays of our first mergeSort function
	 * compare the values of the split arrays and sort lowest to highest 
	 * 
	 * @param inputArray - desired array
	 * @param leftHalf - left half of split array
	 * @param rightHalf - right half of split array
	 */
	private static void merge(int[] inputArray, int[] leftHalf, int[] rightHalf) {
		//get sizes of each array
		int leftSize = leftHalf.length;
		int rightSize = rightHalf.length;
		
		
		int i = 0; //left half iterator 
		int j = 0; //right half iterator 
		int k = 0; //merged array iterator
		
		//loop and compare left and right, smaller integer is added to the merged array
		while (i < leftSize && j < rightSize) {
			
			//increment comp count 
			mergeComparisons++;
			
			if (leftHalf[i] <= rightHalf[j]) {
				inputArray[k] = leftHalf[i];
				i++;
			}
			else {
				inputArray[k] = rightHalf[j];
				j++;
			}
			k++;
		}
		
		//add all leftover leftHalf array to end of merged array (clean up)
		while (i < leftSize) {
			inputArray[k] = leftHalf[i];
			i++;
			k++;
		}
		
		//add all leftover right array to end of merged array (clean up)
		while (j < rightSize) {
			inputArray[k] = rightHalf[j];
			j++;
			k++;
		}	
	}
	
	
// QUICK SORT	
	/**
	 * Quick Sort pt1
	 * using quick sort, and setting a pivot, we move all items lower and higher than
	 * the index left and right respectively
	 * 
	 * @param array
	 * @param lowIndex
	 * @param highIndex
	 */
	public static void quickSort(int[] array, int lowIndex, int highIndex) {
		//check if we can exit the recursive loops
		if(lowIndex >= highIndex) {
			return;
		}
		//set pivot point
		int pivot = array[highIndex];
		//partition
		int leftPointer = lowIndex;
		int rightPointer = highIndex;
		
		while (leftPointer < rightPointer) {

		    while (leftPointer < rightPointer) {
		        quickComparisons++;

		        if (array[leftPointer] <= pivot) {
		            leftPointer++;
		        } else {
		            break;
		        }
		    }

		    while (leftPointer < rightPointer) {
		        quickComparisons++;

		        if (array[rightPointer] >= pivot) {
		            rightPointer--;
		        } else {
		            break;
		        }
		    }

		    if (leftPointer < rightPointer) {
		        swap(array, leftPointer, rightPointer);
		    }
		}
		
		swap(array, leftPointer, highIndex);
		
		//recursively work through left and right of our initial pivot
		quickSort(array, lowIndex, leftPointer-1); //left
		quickSort(array, leftPointer +1, highIndex); //right
		
		
		
	}
	
	/**
	 * Quick Sort part 2
	 * using this swap function we can move the elements of our array
	 * that out pointers indicate in out main quick sort method.
	 * 
	 * @param array - array being sorted
	 * @param index1 - element being swapped
	 * @param index2 - element being swapped
	 */
	private static void swap(int[] array, int index1, int index2) {
		int temp = array[index1];
		array[index1] = array[index2];
		array[index2] = temp;
		
	}
	
//HEAP SORT
	/**
	 * Builds a heap from the input array and extracts the largest
	 * element by swapping the roots. Reduces in size for each recursion. 
	 * 
	 * @param arr - the array to be sorted
	 */
	public static void heapSort(int[] arr) {
		int n = arr.length;
		
		for (int i = n/2-1; i>=0; i--) {
			heapify(arr, n, i);
		}
		
		for(int i = n-1; i>0; i--) {
			int temp = arr[0];
			arr[0] = arr[i];
			arr[i] = temp;
			
			heapify(arr, i, 0);
		}
	}
	
	/**
	 * Compares parent node with its left and right children
	 * and swaps largest if needed.
	 * 
	 * @param arr - the heap array
	 * @param n - the size of the heap portion of the array
	 * @param i - the index of the current root of the subtree.
	 */
	public static void heapify(int[] arr, int n, int i) {
		//compare the elements to the left and right of i
		int largest = i;
		int left = 2*i+1;
		int right = 2*i+2;
		
		if(left < n) {
			heapComparisons++;
			if (arr[left] > arr[largest]) {
				largest = left;
			}
		}
			
			
		if(right < n) {
			heapComparisons++;
			if (arr[right]> arr[largest]) {
				largest = right;
			}
		}
		
		if (largest != i) {
			int temp = arr[largest];
			arr[largest] = arr[i];
			arr[i] = temp;
			
			//call recursion if and only if swap happens
			heapify(arr, n, largest);
		}
	}

//SHAKER SORT
	/**
	 * Sorts an array using the Shaker Sort algorithm,
	 * The algorithm makes alternating  passes
	 * through the array, swapping adjacent elements that
	 * are out of order until the array is fully sorted.
	 *
	 * @param arr the array to be sorted
	 */
	public static void shakerSort(int[] arr) {
	    boolean swapped = true;

	    int start = 0;
	    int end = arr.length - 1;

	    while (swapped) {

	        swapped = false;

	        // Left to Right pass
	        for (int i = start; i < end; i++) {
	            shakerComparisons++;

	            if (arr[i] > arr[i + 1]) {
	                swap(arr, i, i + 1);
	                swapped = true;
	            }
	        }

	        // If no swaps occurred, array is sorted
	        if (!swapped) {
	            break;
	        }

	        swapped = false;
	        end--;

	        // Right to Left pass
	        for (int i = end; i > start; i--) {
	            shakerComparisons++;

	            if (arr[i] < arr[i - 1]) {
	                swap(arr, i, i - 1);
	                swapped = true;
	            }
	        }

	        start++;
	    }
	}
	
	/**
	 * keep track of all test results for the results table
	 */
	static class Result {
	    int n;
	    long merge;
	    long quick;
	    long heap;
	    long shaker;

	    Result(int n, long merge, long quick,
	           long heap, long shaker) {
	        this.n = n;
	        this.merge = merge;
	        this.quick = quick;
	        this.heap = heap;
	        this.shaker = shaker;
	    }
	}
	

	public static void main(String[] args) {
				
		// set the sizes of arrays we want to sort
		int [] sizes = {4,6,8,44,66,88,100};	
		
		ArrayList<Result> results = new ArrayList<>();
		
		System.out.println("Algorithm Performance Testing");
		System.out.println("========================");
		//THE MEAT of the project, create the arrays, print them, call sort functions, ect.
		for (int size : sizes ) {
			//create array
			int[] original = generateRandomArray(size);
			
			//print OG Array
			System.out.println("========================");
			System.out.println("Array Size " + original.length);
			System.out.println();	
			System.out.print("Original Array:");
			printArray(original);
			
			
			//Merge Sort
			System.out.println();
			mergeComparisons = 0;//reset comp tracker before each call
			int[] mergeArray = copy(original);
			mergeSort(mergeArray);
			System.out.print("Merge Sort: ");
			printArray(mergeArray);
			System.out.println("Comparison Count: " + mergeComparisons);
			
			
			//Quick Sort
			System.out.println();
			quickComparisons = 0;//reset comp tracker
			int[] quickArray = copy(original);
			System.out.print("Quick Sort: ");
			quickSort(quickArray, 0, quickArray.length - 1);
			printArray(quickArray);
			System.out.println("Comparison Count: " + quickComparisons);
			
			//Heap Sort
			System.out.println();
			heapComparisons = 0;
			int [] heapArray = copy(original);
			System.out.print("Heap Sort: ");
			heapSort(heapArray);
			printArray(heapArray);
			System.out.println("Comparison Count: " + heapComparisons);
			
			//Shaker Sort
			System.out.println();
			shakerComparisons = 0;
			int [] shakerArray = copy(original);
			System.out.print("Shaker Sort: ");
			shakerSort(shakerArray);
			printArray(shakerArray);
			System.out.println("Comparison Count: " + shakerComparisons);
			
			//add results to table
			results.add(new Result(
			        size,
			        mergeComparisons,
			        quickComparisons,
			        heapComparisons,
			        shakerComparisons));
			
			System.out.println();
			System.out.println("========================");	
			
		}
		
		//print table
		System.out.println("========================");
		System.out.println("\nFINAL RESULTS TABLE");
		System.out.println("-----------------------------------------------------");
		System.out.printf("%-5s %-10s %-10s %-10s %-10s%n",
		        "n", "Merge", "Quick", "Heap", "Shaker");
		System.out.println("-----------------------------------------------------");

		for (Result r : results) {
		    System.out.printf("%-5d %-10d %-10d %-10d %-10d%n",
		            r.n,
		            r.merge,
		            r.quick,
		            r.heap,
		            r.shaker);
		}	

	}

}
