/**
 * Andrew Long
 * Prof John McGowan
 * CSIS-2430-501-Summer
 * June 27, 2026
 * 
 */

package project2;

public class Main {
	
	
	//create universal set
	static String[] universalSet  = {"A", "B", "C", "D", "E","F", "G", "H", "I", "J", "K", "L"};
	
	//create subsets using boolean arrays for part 1
	static boolean[] setA = {true, true, false, true, false, false, false, true, false, true, true, true};
	static boolean[] setB = {true, true, false, false, false, false, true, true, false, true, false, true};
	
	//create mutlisets for part 2
	static int[] multisetA = {8,1,0,4,0,2,1,2,3,8,2,9};
	static int[] multisetB = {6,0,2,1,1,1,4,2,3,6,4,5};
	
	
	/**
	 * A helper method to print out each set of our project
	 * 
	 * @param set
	 */
	public static void printElements(String[] set) {
		for (String element : set) {
			System.out.print(element + " ");
	    }
	    System.out.println();
	}
	  
	/**
	 * Print the boolean array, and what the boolean values represent in the set
	 * 
	 * @param set
	 */
	  public static void printSet(boolean[] set) {
		  System.out.print("Bit String: ");
		  for (boolean value : set) {
			  System.out.print(value ? "1" : "0");
		  }
		  
		  System.out.print("\nElements: { ");
		  for (int i = 0; i < set.length; i++) {
			  if(set[i]) {
				  System.out.print(universalSet[i] + " ");
			  }
		  }
		  System.out.println("}");
		  
	  }
	  
	  /**
	   * helper method to print multiset data
	   * @param set
	   */
	  public static void printMultiset(int[] set) {
		  
		  System.out.print("Element Counts: {");
		  
		  for(int i = 0; i < set.length; i++) {
			  System.out.print(universalSet[i] + ": " + set[i]);
			  
			  if (i < set.length - 1) {
				  System.out.print(", ");
			  }
		  }
		  
		  System.out.println(" }");
	  }
	
	  /**
	   * loop through setA and use the logical operator != to change the binary string
	   * @param set
	   * @return
	   */
	  public static boolean[] complement(boolean[] set) {
		
		boolean[] result = new boolean[set.length];
		
		for (int i = 0; i < set.length; i++) {
			result[i] = !set[i];
		}
		
		return result;
	}
	  
	  /**
	   * Use the logical OR || to create the union of two sets
	   * What is in A OR B
	   * 
	   * @param A
	   * @param B
	   * @return
	   */
	  public static boolean[] union(boolean[] A, boolean[] B) {
		  
		  boolean[] result = new boolean[A.length];
		  
		  for( int i = 0; i < A.length; i++) {
			  result[i] = A[i] || B[i];
		  }
		  
		  return result;
	  }
	  
	  
	  /**
	   * Use the logical AND && to create the intersection of two sets
	   * What is in A AND B
	   * 
	   * @param A
	   * @param B
	   * @return
	   */
	  public static boolean[] intersection(boolean[] A, boolean[] B) {
		  
		  boolean[] result = new boolean[A.length];
		  
		  for( int i = 0; i < A.length; i++) {
			  result[i] = A[i] && B[i];
		  }
		  
		  return result;
		  
	  }
	  
	  /**
	   * Use logical operator AND && and not ! to create the difference of the sets
	   * What is in A AND NOT in B. 
	   * 
	   * @param A
	   * @param B
	   * @return
	   */
	  public static boolean[] difference(boolean[] A, boolean[] B) {
		  
		  boolean[] result = new boolean[A.length];
		  
		  for(int i = 0; i < A.length; i++) {
			  result[i] = A[i] && !B[i];
		  }
		  
		  return result;
		  
	  }
	  
	  /**
	   * Use logical XOR ^ operator to create the symmetrical difference of the sets
	   * What is in A OR B but not both
	   * @param A
	   * @param B
	   * @return
	   */
	  public static boolean[] symmetricDifference(boolean[] A, boolean[] B) {
		  
		  boolean[] result = new boolean[A.length];
		  
		  for(int i = 0; i < A.length; i++) {
			  result[i] = A[i] ^ B[i];
		  }
		  
		  return result;
	  }
	  
	  /**
	   * Use the Math.max function to get the larger element of each part of the multiset
	   * 
	   * @param A
	   * @param B
	   * @return
	   */
	  public static int[] multisetUnion(int[] A, int[] B) {
		  
		  int[] result = new int[A.length];
		  
		  for(int i = 0; i < A.length; i++) {
			  result[i] = Math.max(A[i], B[i]);
		  }
		  
		  return result;
	  }
	  
	  /**
	   * Use the Math.min function to get the larger element of each part of the multiset
	   * 
	   * @param A
	   * @param B
	   * @return
	   */
	  public static int[] multisetIntersection(int[] A, int[] B) {
			  
		  int[] result = new int[A.length];
			  
		  for(int i = 0; i < A.length; i++) {
			  result[i] = Math.min(A[i], B[i]);
		  }
			  
		  return result;
	  }
	  
	  
	  /**
	   * Subtract B's count from A's multiset, without the ability to go to ZERO.
	   * @param A
	   * @param B
	   * @return
	   */
	  public static int[] multisetDifference(int[] A, int[] B) {
		  
		  int[] result = new int[A.length];
		  
		  for (int i = 0; i < A.length; i++) {
			  result[i]= A[i] - B[i];
			  
			  if (result[i] < 0) {
				  result[i] = 0;
			  }
		  }
		  
		  return result;
	  }
	  
	  public static int[] multisetSum(int[] A, int[] B) {
		  
		  int[] result = new int[A.length];
		  
		  for (int i = 0; i < A.length; i++) {
			  result[i] = A[i] + B[i];
		  }
		  
		  return result;
	  }
	  

	  public static void main(String[] args) {
		
		//PART 1
		System.out.println("PART 1");
		System.out.println("===============================");
		
		
		System.out.println("UNIVERSAL SET:");
		printElements(universalSet);
		
		 System.out.println("\nSET A");
	     printSet(setA);

	     System.out.println("\nSET B");
	     printSet(setB);
	     
	     System.out.println("\nNOT(A) - complement of A");
	     printSet(complement(setA));
	     
	     System.out.println("\nA ∪ B - union");
	     printSet(union(setA, setB));
	     
	     System.out.println("\nA ∩ B - intersection");
	     printSet(intersection(setA, setB));
	     
	     System.out.println("\nA - B - difference");
	     printSet(difference(setA, setB));
	     
	     System.out.println("\nA ⊕ B – symmetric difference");
	     printSet(symmetricDifference(setA, setB));
	     
	   //PART 2
	    System.out.println();
	    System.out.println();
		System.out.println("PART 2");
		System.out.println("===============================");
		
		System.out.println("\nMULTISET A");
		printMultiset(multisetA);
		
		System.out.println("\nMULTISET B");
		printMultiset(multisetB);
		
		System.out.println("\nMULTISET UNION (A ∪ B):");
		printMultiset(multisetUnion(multisetA, multisetB));
		
		System.out.println("\nMULTISET INTERSECTION (A ∩ B): ");
		printMultiset(multisetIntersection(multisetA, multisetB));
	     
		System.out.println("\nMULTISET DIFFERENCE (A - B): ");
		printMultiset(multisetDifference(multisetA, multisetB)); 
		
		System.out.println("\nMULTISET SUM (A + B): ");
		printMultiset(multisetSum(multisetA, multisetB)); 
		
				
	}

}
