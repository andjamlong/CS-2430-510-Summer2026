package project2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Project2Test {


	@Test
    public void testComplement() {
        boolean[] input = {true, false, true, false};
        boolean[] expected = {false, true, false, true};

        assertArrayEquals(expected, Main.complement(input));
    }

    @Test
    public void testUnion() {
        boolean[] A = {true, false, true, false};
        boolean[] B = {false, true, true, false};

        boolean[] expected = {true, true, true, false};

        assertArrayEquals(expected, Main.union(A, B));
    }
    
    @Test
    public void testEmptySetUnion() {
        boolean[] empty = {false, false, false, false};
        boolean[] set = {true, false, true, true};

        boolean[] expected = {true, false, true, true};

        assertArrayEquals(expected, Main.union(empty, set));
    }

    @Test
    public void testIntersection() {
        boolean[] A = {true, false, true, false};
        boolean[] B = {false, true, true, false};

        boolean[] expected = {false, false, true, false};

        assertArrayEquals(expected, Main.intersection(A, B));
    }

    @Test
    public void testDifference() {
        boolean[] A = {true, true, true, false};
        boolean[] B = {false, true, false, true};

        boolean[] expected = {true, false, true, false};

        assertArrayEquals(expected, Main.difference(A, B));
    }

    @Test
    public void testSymmetricDifference() {
        boolean[] A = {true, false, true, false};
        boolean[] B = {false, true, true, false};

        boolean[] expected = {true, true, false, false};

        assertArrayEquals(expected, Main.symmetricDifference(A, B));
    }

    @Test
    public void testMultisetUnion() {
        int[] A = {3, 5, 1};
        int[] B = {4, 2, 7};

        int[] expected = {4, 5, 7};

        assertArrayEquals(expected, Main.multisetUnion(A, B));
    }

    @Test
    public void testMultisetIntersection() {
        int[] A = {3, 5, 1};
        int[] B = {4, 2, 7};

        int[] expected = {3, 2, 1};

        assertArrayEquals(expected, Main.multisetIntersection(A, B));
    }

    @Test
    public void testMultisetDifference() {
        int[] A = {8, 5, 3};
        int[] B = {2, 3, 1};

        int[] expected = {6, 2, 2};

        assertArrayEquals(expected, Main.multisetDifference(A, B));
    }

    @Test
    public void testMultisetDifferenceEdgeCase() {
        int[] A = {1, 2, 0};
        int[] B = {5, 1, 3};

        int[] expected = {0, 1, 0};

        assertArrayEquals(expected, Main.multisetDifference(A, B));
    }

    @Test
    public void testMultisetSum() {
        int[] A = {1, 2, 3};
        int[] B = {4, 5, 6};

        int[] expected = {5, 7, 9};

        assertArrayEquals(expected, Main.multisetSum(A, B));
    }

}
