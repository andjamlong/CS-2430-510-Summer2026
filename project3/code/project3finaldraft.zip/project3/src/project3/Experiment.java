package project3;

public class Experiment {
	
	String name;
	int weight;
	int rating;
	
	
	//Constructor
	public Experiment (String name, int weight, int rating) {
		this.name = name;
		this.weight = weight;
		this.rating = rating;
	}
	
	
	public String getName() {
		return name;
	}


	public int getWeight() {
		return weight;
	}


	public int getRating() {
		return rating;
	}


	//returns rating divided by weight
	public double getRatio() {
		return (double) rating / weight;
	}


	public static void main(String[] args) {
		
		
	}

}
