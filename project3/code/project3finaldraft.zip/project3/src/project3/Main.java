package project3;

public class Main {

	//initialize our experiments
	static Experiment[] experiments = {

		    new Experiment("Cloud Patterns",36,5),
		    new Experiment("Solar Flares",264,9),
		    new Experiment("Solar Power",188,6),
		    new Experiment("Binary Stars",203,8),
		    new Experiment("Relativity",104,8),
		    new Experiment("Seed Viability",7,4),
		    new Experiment("Sun Spots",90,2),
		    new Experiment("Mice Tumors",65,8),
		    new Experiment("Microgravity Plant Growth",75,5),
		    new Experiment("Micrometeorites",170,9),
		    new Experiment("Cosmic Rays",80,7),
		    new Experiment("Yeast Fermentation",27,4)

	};
	
	//var to store our results
	static int highestRatingWeight;
	static int highestRatingRating;

	static int lightestWeightWeight;
	static int lightestWeightRating;

	static int ratioWeightWeight;
	static int ratioRatingRating;
	
	
	
	/**
	 * makes a clone of the experiments array and sorts by rating
	 * 
	 */
	public static void highestRatingFirst() {
		
		//make copy of array so we can rearrange it
		Experiment[] sorted = experiments.clone();
		
		//sort by rating
		for (int i = 0; i < sorted.length - 1; i++) {
			
			int maxIndex = i;
			
			for (int j = i +1; j < sorted.length; j++ ) {
				
				if (sorted[j].rating > sorted[maxIndex].rating) {
					maxIndex = j;
				}
			}
			
			Experiment temp = sorted[i];
			sorted[i] = sorted[maxIndex];
			sorted[maxIndex] = temp;
			
		}
		
	
		
		System.out.println("Highest Rated First");
		System.out.println("===================");
		
		Result r = greedyKnapsack(sorted);

	    highestRatingWeight = r.weight;
	    highestRatingRating = r.rating;
	
	}
	
	/**
	 * makes a clone of the experiments array and sorts by weight
	 * 
	 */
	public static void lightestWeightFirst() {
		
		Experiment[] sorted = experiments.clone();
		
		//Sort by weight
		for (int i = 0; i < sorted.length - 1; i++) {
			
			int maxIndex = i;
			
			for (int j = i +1; j < sorted.length; j++ ) {
				
				if (sorted[j].weight < sorted[maxIndex].weight) {
					maxIndex = j;
				}
			}
			
			Experiment temp = sorted[i];
			sorted[i] = sorted[maxIndex];
			sorted[maxIndex] = temp;
			
		}
		
	
		
		System.out.println("Lightest Weight First");
		System.out.println("===================");
		
		
		
		Result r = greedyKnapsack(sorted);

		lightestWeightWeight = r.weight;
		lightestWeightRating = r.rating;
	}

	/**
	 * makes a clone of the experiments array and sorts by weight to rating ratio
	 * 
	 */
	public static void bestPointToWeightRatio() {
		
		Experiment[] sorted = experiments.clone();
		
		//Sort by point ratio
		for (int i = 0; i < sorted.length - 1; i++) {
			
			int maxIndex = i;
			
			for (int j = i +1; j < sorted.length; j++ ) {
				
				if (sorted[j].getRatio() > sorted[maxIndex].getRatio()) {
					maxIndex = j;
				}
			}
			
			Experiment temp = sorted[i];
			sorted[i] = sorted[maxIndex];
			sorted[maxIndex] = temp;
			
		}
		
	
		System.out.println("Best Point to Weight Ratio First");
		System.out.println("===================");
		
		Result r = greedyKnapsack(sorted);

		ratioWeightWeight = r.weight;
		ratioRatingRating = r.rating;
	}

	/**
	 * Takes sorted experiments and goes line by line to add them to our shuttle, 
	 * as long as in doing so we don't exceed our weight limit of 700.
	 * Prints results
	 * 
	 * @param sorted
	 * @param totalWeight
	 * @param totalRating
	 */
	private static Result greedyKnapsack(Experiment[] sorted) {
		
		int totalWeight = 0;
		int totalRating = 0; 
		for (Experiment e : sorted) {
			
			if  (totalWeight + e.weight <= 700) {
				totalWeight += e.weight;
				totalRating += e.rating;
				
				System.out.println(e.name + ": " + e.weight + "kg, Rating " + e.rating + "");
			}
		}
		
		System.out.println("Total Weight: " + totalWeight);
		System.out.println("Total Rating: " + totalRating);
		return new Result(totalWeight, totalRating);
	}
	
	/**
	 * Helper Method to store results of greedy knapsack attempts
	 */
	public static class Result {
	    int weight;
	    int rating;

	    public Result(int weight, int rating) {
	        this.weight = weight;
	        this.rating = rating;
	    }
	}
	
	/**
	 * Print results from part 1
	 */
	private static void part1Results() {
		System.out.println("Part 1: Greedy Strategies");
		System.out.println();
		highestRatingFirst();
		System.out.println();
		System.out.println();
		lightestWeightFirst();
		System.out.println();
		System.out.println();
		bestPointToWeightRatio();
	
	}
	
	//Part 2
	//create global vars for just the best option for part 3
	static int bestRating = 0;
	static int bestMask = 0;
	/**
	 * Brute force all checks of our set, by using bitmasking
	 * to create a powerset. As we only need our top three exp we don't
	 * store any results unless they are currently top 3. 
	 */
	public static void bruteForceKnapsack() {
		//track our top 3 results
		bestRating = 0;
		int secondBest = 0;
		int thirdBest = 0;
		//store bitmask representations of top 3 results
		bestMask = 0;
		int secondMask = 0;
		int thirdMask = 0;
		
		//4096 checks
		for (int mask = 0; mask < 4096; mask++) {
			
			int totalWeight = 0;
			int totalRating = 0;
			
			//subset
			for (int i = 0; i < experiments.length; i++) {
				// use bitmask to determine if i is included in our subset
				if ((mask & (1 << i)) !=0) {
					totalWeight += experiments[i].weight;
					totalRating += experiments[i].rating;
					
				}
			}
			
			//confirm if under weight
			if (totalWeight <= 700) {
				//check to see if rating beats any of our current top 3, no need to store anything else
				if (totalRating > bestRating) {
					thirdBest = secondBest;
					thirdMask = secondMask;
					
					secondBest = bestRating;
					secondMask = bestMask;
					
					bestRating = totalRating;
					bestMask = mask;
					
				} else if (totalRating > secondBest) {
					thirdBest = secondBest;
					thirdMask = secondMask;
					
					secondBest = totalRating;
					secondMask = mask;					
				} else if (totalRating > thirdBest) {
					thirdBest = totalRating;
					thirdMask = mask;
				}
			}
		}
		
		printSubset("BEST", bestMask);
	    printSubset("SECOND BEST", secondMask);
	    printSubset("THIRD BEST", thirdMask);
	}
	
	/**
	 * helper method to print our top 3 subsets
	 * @param label
	 * @param mask
	 */
	public static void printSubset(String label, int mask) {
		
		//reset vars
	    int totalWeight = 0;
	    int totalRating = 0;

	    System.out.println("\n" + label + " SUBSET:");
	    System.out.println("===================");

	    for (int i = 0; i < experiments.length; i++) {

	        if ((mask & (1 << i)) != 0) {

	            Experiment e = experiments[i];

	            System.out.println(e.name + " (" + e.weight + ", " + e.rating + ")");

	            totalWeight += e.weight;
	            totalRating += e.rating;
	        }
	    }

	    System.out.println("Total Weight: " + totalWeight);
	    System.out.println("Total Rating: " + totalRating);
	}
	
	//Part 3
	public static void comparisonSummary() {

	    System.out.println("\nPART 3 SUMMARY");
	    System.out.println("====================");

	    System.out.println("Highest Rating First");
	    System.out.println("Weight: " + highestRatingWeight);
	    System.out.println("Rating: " + highestRatingRating);

	    System.out.println("\nLightest Weight First");
	    System.out.println("Weight: " + lightestWeightWeight);
	    System.out.println("Rating: " + lightestWeightRating);

	    System.out.println("\nBest Ratio First");
	    System.out.println("Weight: " + ratioWeightWeight);
	    System.out.println("Rating: " + ratioRatingRating);

	    System.out.println("\nBrute Force Optimal");
	    System.out.println("Rating: " + bestRating);

	    System.out.println("\nComparison:");

	    if (highestRatingWeight == bestRating)
	        System.out.println("Highest Rating First matched optimal.");
	    else
	        System.out.println("Highest Rating First did NOT match optimal.");

	    if (lightestWeightRating == bestRating)
	        System.out.println("Lightest Weight First matched optimal.");
	    else
	        System.out.println("Lightest Weight First did NOT match optimal.");

	    if (ratioRatingRating == bestRating)
	        System.out.println("Best Ratio First matched optimal.");
	    else
	        System.out.println("Best Ratio First did NOT match optimal.");
	}
	
	//Part 4 DP
	/**
	 * Solves the Knapsack Using Dynamic Programming
	 * It builds a table where dp[i][w] represents the total rating
	 * using experiments i with the weight limit w. 
	 * 
	 * Considers each experiment one at a time and decides whether to include it 
	 * or exclude it based on the choice that results in a higher rating without
	 * going over weight limit.
	 * 
	 * After table is filled, the method tracks back through the table to determine which
	 * experiments are optimal to include
	 */
	public static void dynamicProgrammingKnapsack() {

	    int n = experiments.length;
	    int W = 700;

	    int[][] dp = new int[n + 1][W + 1];

	    // build DP table
	    for (int i = 1; i <= n; i++) {

	        Experiment e = experiments[i - 1];

	        for (int w = 0; w <= W; w++) {

	            if (e.weight <= w) {

	                dp[i][w] = Math.max(
	                        dp[i - 1][w],
	                        e.rating + dp[i - 1][w - e.weight]
	                );

	            } else {
	                dp[i][w] = dp[i - 1][w];
	            }
	        }
	    }

	    //print result
	    System.out.println("\nDP OPTIMAL SOLUTION");
	    System.out.println("===================");

	    int w = W;
	    int totalWeight = 0;

	    for (int i = n; i > 0 && w > 0; i--) {

	        if (dp[i][w] != dp[i - 1][w]) {

	            Experiment e = experiments[i - 1];

	            System.out.println(e.name + " (" + e.weight + ", " + e.rating + ")");

	            totalWeight += e.weight;
	            w -= e.weight;
	        }
	    }

	    System.out.println("Total Rating: " + dp[n][W]);
	    System.out.println("Total Weight: " + totalWeight);
	}
	
	public static void main(String[] args) {

		//Print Results from part 1
		part1Results();
		
		//Print Results from part 2
		System.out.println();
		System.out.println("Part 2: Brute Force");
		bruteForceKnapsack();
		
		//part 3
		comparisonSummary();
		
		//Part 4 
		dynamicProgrammingKnapsack();
	}

	

}
