package project4;

public class Main {
	
	
	

	public static void main(String[] args) {
		int[] turnCounts =
	            {1000, 10000, 100000};
	
		for (JailStrategy strategy : JailStrategy.values()) {
	
	        System.out.println();
	        System.out.println(
	            "====================================");
	        System.out.println(strategy);
	        System.out.println(
	            "====================================");
	
	        for (int simulation = 1;
	             simulation <= 2;
	             simulation++) {
	
	            for (int turns : turnCounts) {
	
	                MonopolyGame game =
	                    new MonopolyGame(strategy);
	
	                game.runSimulation(turns);
	
	                System.out.println();
	                System.out.println(
	                    "Simulation " + simulation);
	                System.out.println(
	                    "Turns = " + turns);
	
	                game.printResults();
	                
	            }
	        }
		}

	}

}
