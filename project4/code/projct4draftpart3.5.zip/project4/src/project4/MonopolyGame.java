package project4;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;



public class MonopolyGame {
	
	//create board, dice and strategies
	private BoardSquare[] square = new BoardSquare[40];
	private Random random = new Random();
	private JailStrategy jailStrategy;
	
	//Player Information
	private int position = 0; //start at index 0
	private boolean inJail = false;
	private int doublesCount= 0;
	private int jailTurns = 0;
	private int getOutOfJailCards = 0;
	
	//stats
	private int totalMoves = 0;
	
	//Chance
	private Queue<String> chanceDeck = new LinkedList<>();
    private Queue<String> chanceDiscard = new LinkedList<>();
    
    // Community Chest
    private Queue<String> communityDeck = new LinkedList<>();
    private Queue<String> communityDiscard = new LinkedList<>();
   
    
    //Create the spaces of the board game
    public void createBoard() {
    	square[0] = new BoardSquare("Go", "Go");
    	square[1] = new BoardSquare("Mediterranean Avenue", "Property");
    	square[2] = new BoardSquare("Community Chest", "Community Chest");
    	square[3] = new BoardSquare("Baltic Avenue", "Property");
    	square[4] = new BoardSquare("Income Tax", "Tax");
    	square[5] = new BoardSquare("Reading Railroad", "Railroad");
    	square[6] = new BoardSquare("Oriental Avenue", "Property");
    	square[7] = new BoardSquare("Chance","Chance");
    	square[8] = new BoardSquare("Vermot Avenue","Property");
    	square[9] = new BoardSquare("Connecticut Avenue","Property");
    	square[10] = new BoardSquare("Jail / Just Visiting","Jail");
    	square[11] = new BoardSquare("St. Charles Place","Proprty");
    	square[12] = new BoardSquare("Electric Company","Utility");
    	square[13] = new BoardSquare("States Avenue","Proprty");
    	square[14] = new BoardSquare("Virginia Avenue","Property");
    	square[15] = new BoardSquare("Pennsylvania Railroad","Railroad");
    	square[16] = new BoardSquare("St. James Plance","Proprerty");
    	square[17] = new BoardSquare("Community Chest","Community Chest");
    	square[18] = new BoardSquare("Tennessee Avenue","Property");
    	square[19] = new BoardSquare("New York Avenue","Property");
    	square[20] = new BoardSquare("Free Parking","Free Parking");
    	square[21] = new BoardSquare("Kentucky Avenue","Property");
    	square[22] = new BoardSquare("Chance","Chance");
    	square[23] = new BoardSquare("Indiana Avenue","Property");
    	square[24] = new BoardSquare("Illinois Avenue","Property");
    	square[25] = new BoardSquare("B & O RailRoad","Railroad");
    	square[26] = new BoardSquare("Atlantic Avenue","Property");
    	square[27] = new BoardSquare("Ventnor Avenue","Property");
    	square[28] = new BoardSquare("Water Works","Utility");
    	square[29] = new BoardSquare("Marvin Gardnes","Property");
    	square[30] = new BoardSquare("Go to Jail","Go to Jail");
    	square[31] = new BoardSquare("Pacific Avenue","Property");
    	square[32] = new BoardSquare("North Carolina Avenue","Property");
    	square[33] = new BoardSquare("Community Chest","Community Chest");
    	square[34] = new BoardSquare("Pennsylvania Avenue","Property");
    	square[35] = new BoardSquare("Short Line","Railroad");
    	square[36] = new BoardSquare("Chance","Chance");
    	square[37] = new BoardSquare("Park Place","Property");
    	square[38] = new BoardSquare("Luxary Tax","Tax");
    	square[39] = new BoardSquare("Boardwalk","Property");   	
    	
    }
	
    //create Chance cards
    public void createChanceDeck() {
    	List<String> cards = new ArrayList<>();
    	
    	cards.add("Advance to Boardwalk");
    	cards.add("Advance to Go");
    	cards.add("Advance to Illinois Avenue");
    	cards.add("Advance to St. Charles Place");
    	cards.add("Advance to the nearest Railroad");
    	cards.add("Advance to the nearest Railroad");
    	cards.add("Advance token to nearest Utility");
    	cards.add("Bank pays you dividend of $50");
    	cards.add("Get Out of Jail Free");
    	cards.add("Go Back 3 Spaces");
    	cards.add("Go to Jail");
    	cards.add("Make general repairs on all your property. For each house pay $25. For each hotel pay $100");
    	cards.add("Speeding fine $15");
    	cards.add("Take a trip to Reading Railroad");
    	cards.add("You have been elected Chairman of the Board. Pay each player $50");
    	cards.add("Your building loan matures. Collect $150");
    	
    	
    	Collections.shuffle(cards);
    	
    	chanceDeck.addAll(cards);
    	
    }
    
    //create Community Chest cards
    private void createCommunityChestDeck() {
    	List<String> cards = new ArrayList<>();
    	
    	cards.add("Advance to Go");
    	cards.add("Bank error in your favor. Collect $200");
    	cards.add("Doctor’s fee. Pay $50");
    	cards.add("From sale of stock you get $50");
    	cards.add("Get Out of Jail Free");
    	cards.add("Go to Jail");
    	cards.add("Holiday fund matures. Receive $100");
    	cards.add("Income tax refund. Collect $20");
    	cards.add("It is your birthday. Collect $10 from every player");
    	cards.add("Life insurance matures. Collect $100");
    	cards.add("Pay hospital fees of $100");
    	cards.add("Pay school fees of $50");
    	cards.add("Receive $25 consultancy fee");
    	cards.add("You are assessed for street repair. $40 per house. $115 per hotel");
    	cards.add("You have won second prize in a beauty contest. Collect $10");
    	cards.add("You inherit $100");
    
    	
        Collections.shuffle(cards);
        
        communityDeck.addAll(cards);
    	
    	
    }
    
    //roll dice
    private int rollDie() {
    	return random.nextInt(6)+1;
    }
    
    //move the player
    private void movePlayer(int spaces) {

        position += spaces;

        if (position >= 40)
            position %= 40;
    }
    
    //go to jail
    private void goToJail() {

        position = 10;
        inJail = true;
        jailTurns = 0;
    }
    
    //handle Jail Logic option 1
    private boolean handleJail() {

        if (!inJail)
            return false;

        // Use a Get Out of Jail Free card immediately
        if (getOutOfJailCards > 0) {

            getOutOfJailCards--;
            inJail = false;
            jailTurns = 0;

            return false;
        }

        if (jailStrategy == JailStrategy.IMMEDIATE_EXIT) {

            inJail = false;
            jailTurns = 0;

            return false;
        }

        // Strategy B
        return tryForDoublesStrategy();
    }
    
    //handle Jail Logic option 2
    private boolean tryForDoublesStrategy() {

        jailTurns++;

        int die1 = rollDie();
        int die2 = rollDie();

        if (die1 == die2) {

            inJail = false;
            jailTurns = 0;

            movePlayer(die1 + die2);

            return true;
        }

        if (jailTurns >= 3) {

            inJail = false;
            jailTurns = 0;

            return false;
        }

        return true;
    }
    
    //draw cards/card effects Chance
    private void drawChanceCard() {

        if (chanceDeck.isEmpty()) {
            reshuffleChance();
        }

        String card = chanceDeck.remove();
        chanceDiscard.add(card);

        switch(card) {

            case "Advance to Go":
                position = 0;
                break;

            case "Go to Jail":
                goToJail();
                return;

            case "Advance to Illinois Avenue":
                position = 24;
                break;

            case "Advance to St. Charles Place":
                position = 11;
                break;

            case "Take a trip to Reading Railroad":
                position = 5;
                break;

            case "Advance to Boardwalk":
                position = 39;
                break;

            case "Go Back 3 Spaces":
                position = (position + 37) % 40;
                resolveSquare();
                break;
            
            case "Get Out of Jail Free":
            	getOutOfJailCards++;
            	break;

            default:
                break;
        }
    }
    
    //reshuffle chance
    private void reshuffleChance() {

        chanceDeck.addAll(chanceDiscard);
        chanceDiscard.clear();

        List<String> temp = new ArrayList<>(chanceDeck);
        Collections.shuffle(temp);

        chanceDeck.clear();
        chanceDeck.addAll(temp);
    }
    
    //draw cards/card effects Community Chest
    private void drawCommunityChestCard() {

        if (communityDeck.isEmpty()) {
            reshuffleCommunity();
        }

        String card = communityDeck.remove();
        communityDiscard.add(card);

        switch(card) {

            case "Advance to GO":
                position = 0;
                break;

            case "Go to Jail":
                goToJail();
                break;
                
            case "Get Out of Jail Free":
            	getOutOfJailCards++;
            	break;

            default:
                break;
        }
    }
    
    //reshuffle Community Chest
    private void reshuffleCommunity() {

        communityDeck.addAll(communityDiscard);
        communityDiscard.clear();

        List<String> temp = new ArrayList<>(communityDeck);
        Collections.shuffle(temp);

        communityDeck.clear();
        communityDeck.addAll(temp);
    }
    
    //board effects
    private void resolveSquare() {

        String type = square[position].getType();

        if (type.equals("Go to Jail")) {

            goToJail();

        } else if (type.equals("Chance")) {

            drawChanceCard();

        } else if (type.equals("Community Chest")) {

            drawCommunityChestCard();
        }
    }
    
    //play a turn
    public void playTurn() {
    	 if (handleJail()) {

    		 square[position].addLanding();
    	     totalMoves++;
    	     return;
    	   }
    	 
    	doublesCount = 0;
    	
    	while (true) {
    		int die1 = rollDie();
    		int die2 = rollDie();
    		
    		if (die1 == die2) {
    			doublesCount++;
    		} else {
    			doublesCount = 0;
    		}
    		
    		if (doublesCount == 3) {
    			goToJail();
    			break;
    		}
    		
    		movePlayer(die1 + die2);
    		
    		resolveSquare();
    		
    		if(die1 != die2) {
    			break;
    		}
    		
    		
    	}
    	
    	square[position].addLanding();
    	totalMoves++;
    }
    
    
    
    public MonopolyGame(JailStrategy strategy) {
    	
    	jailStrategy = strategy;
    	
        createBoard();
        createChanceDeck();
        createCommunityChestDeck();
    }
    
    //reset the game for other iterations
    public void resetGame() {

        position = 0;
        inJail = false;
        doublesCount = 0;
        jailTurns = 0;
        getOutOfJailCards = 0;
        totalMoves = 0;

        for (int i = 0; i < square.length; i++) {
            square[i] = new BoardSquare(
                square[i].getName(),
                square[i].getType()
            );
        }

        chanceDeck.clear();
        chanceDiscard.clear();
        communityDeck.clear();
        communityDiscard.clear();

        createChanceDeck();
        createCommunityChestDeck();
    }
    
    //play the game n times
    public void runSimulation(int turns) {

        for (int i = 0; i < turns; i++) {
            playTurn();
        }
    }
	
    //print results of run 
    public void printResults() {

        System.out.println("Total Turns: " + totalMoves);
        System.out.println();

        for (int i = 0; i < square.length; i++) {

            int count = square[i].getLandings();

            double percentage =
                    (double) count / totalMoves * 100;

            System.out.printf(
                "%2d %-25s %10d %10.4f%%%n",
                i,
                square[i].getName(),
                count,
                percentage
            );
        }
    }
	

}
