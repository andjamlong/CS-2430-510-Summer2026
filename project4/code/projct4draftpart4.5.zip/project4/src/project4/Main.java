package project4;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Main {
	
	
	

	public static void main(String[] args) throws FileNotFoundException {
		PrintWriter out = new PrintWriter("MonopolyResults.txt");
		
		int[] turnCounts =
	            {1000, 10000, 100000, 1000000};
		
	
		for (JailStrategy strategy : JailStrategy.values()) {
	
	        out.println();
	        out.println(
	            "====================================");
	        out.println(strategy);
	        out.println(
	            "====================================");
	
	        for (int simulation = 1;
	             simulation <= 10;
	             simulation++) {
	
	            for (int turns : turnCounts) {
	
	                MonopolyGame game =
	                    new MonopolyGame(strategy);
	
	                game.runSimulation(turns);
	
	                out.println();
	                out.println(
	                    "Simulation " + simulation);
	                out.println(
	                    "Turns = " + turns);
	
	                game.printResults(out);
	                game.printSummary(out);
	                
	            }
	        }
		}
		
		out.close();

		System.out.println("Results saved to MonopolyResults.txt");

	}

}
