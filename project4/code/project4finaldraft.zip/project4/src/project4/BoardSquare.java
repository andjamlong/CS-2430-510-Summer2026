package project4;

public class BoardSquare {

	private String name;
	private String type;
	private int landings;
	
	public BoardSquare(String name, String type) {
		this.name = name;
		this.type = type;
		this.landings = 0;
	}
	
	public void addLanding() {
		landings++;
	}

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}

	public int getLandings() {
		return landings;
	}
	
	
	
	
}
