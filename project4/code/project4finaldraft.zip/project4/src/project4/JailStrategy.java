package project4;

public enum JailStrategy {
		IMMEDIATE_EXIT,
		TRY_FOR_DOUBLES
}
