package project4;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Main {
	
	
	

	public static void main(String[] args) throws FileNotFoundException {
		PrintWriter out = new PrintWriter("MonopolyResults.txt");
		
		int[] turnCounts =
	            {1000, 10000, 100000, 1000000};
		
		
		double[] strategyA = new double[40];
		double[] strategyB = new double[40];
		String[] squareNames = new String[40];
		
	
		for (JailStrategy strategy : JailStrategy.values()) {
			
			int[][] topFiveCounts = new int[turnCounts.length][40];
	
	        out.println();
	        out.println(
	            "====================================");
	        out.println(strategy);
	        out.println(
	            "====================================");
	
	        for (int simulation = 1;
	             simulation <= 10;
	             simulation++) {
	
	            for (int turns : turnCounts) {
	
	                MonopolyGame game =
	                    new MonopolyGame(strategy);
	
	                game.runSimulation(turns);
	
	                out.println();
	                out.println(
	                    "Simulation " + simulation);
	                out.println(
	                    "Turns = " + turns);
	
	                game.printResults(out);
	         
	                
	                if (turns == 1000000) {

	                    for (int i = 0; i < 40; i++) {

	                        squareNames[i] = game.getSquare(i).getName();

	                        if (strategy == JailStrategy.IMMEDIATE_EXIT) {

	                            strategyA[i] = game.getPercentage(i);

	                        } else {

	                            strategyB[i] = game.getPercentage(i);
	                        }
	                    }
	                }

	                int[] topFive = game.getTopFiveSquares();

	                for (int index : topFive) {
	                    topFiveCounts[
	                        java.util.Arrays.binarySearch(turnCounts, turns)
	                    ][index]++;
	                }
	               
	                
	            }
	        }
	        
	        for (int turnIndex = 0; turnIndex < turnCounts.length; turnIndex++) {

	            out.println();
	            out.println("======================================");
	            out.println("Top 5 Summary for " + turnCounts[turnIndex] + " Turns");
	            out.println(strategy);
	            out.println("======================================");

	            for (int i = 0; i < 40; i++) {

	                if (topFiveCounts[turnIndex][i] > 1) {

	                    out.printf(
	                        "%-30s appeared in the Top 5 %2d out of 10 simulations%n",
	                        squareNames[i],
	                        topFiveCounts[turnIndex][i]);
	                }
	            }
	        }
		}
		
		
		
		out.println();
		out.println("========== Strategy Comparison ==========");

		for (int i = 0; i < 40; i++) {

		    double difference =
		        Math.abs(strategyA[i] - strategyB[i]);

		    out.printf("%-25s  A: %7.5f%%  B: %7.5f%%  Diff: %7.5f%%%n",
		            squareNames[i],
		            strategyA[i],
		            strategyB[i],
		            difference);
		}
		
		
		out.close();

		System.out.println("Results saved to MonopolyResults.txt");

	}

}
