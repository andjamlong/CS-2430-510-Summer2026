package project4;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;



public class MonopolyGame {
	
	//create board
	private BoardSquare[] square = new BoardSquare[40];
	
	//Player Information
	private int position = 0; //start at index 0
	private boolean inJail = false;
	private int doublesCount= 0;
	private int jailTurns = 0;
	
	//stats
	private int totalMoves = 0;
	
	//Chance
	private Queue<String> chanceDeck = new LinkedList<>();
    private Queue<String> chanceDiscard = new LinkedList<>();
    
    // Community Chest
    private Queue<String> communityDeck = new LinkedList<>();
    private Queue<String> communityDiscard = new LinkedList<>();
    
    public MonopolyGame() {
        createBoard();
        createChanceDeck();
        createCommunityChestDeck();
    }
    
    //Create the spaces of the board game
    public void createBoard() {
    	square[0] = new BoardSquare("Go", "Go");
    	square[1] = new BoardSquare("Mediterranean Avenue", "Property");
    	square[2] = new BoardSquare("Community Chest", "Community Chest");
    	square[3] = new BoardSquare("Baltic Avenue", "Property");
    	square[4] = new BoardSquare("Income Tax", "Tax");
    	square[5] = new BoardSquare("Reading Railroad", "Railroad");
    	square[6] = new BoardSquare("Oriental Avenue", "Property");
    	square[7] = new BoardSquare("Chance","Chance");
    	square[8] = new BoardSquare("Vermot Avenue","Property");
    	square[9] = new BoardSquare("Connecticut Avenue","Property");
    	square[10] = new BoardSquare("Jail / Just Visiting","Jail");
    	square[11] = new BoardSquare("St. Charles Place","Proprty");
    	square[12] = new BoardSquare("Electric Company","Utility");
    	square[13] = new BoardSquare("States Avenue","Proprty");
    	square[14] = new BoardSquare("Virginia Avenue","Property");
    	square[15] = new BoardSquare("Pennsylvania Railroad","Railroad");
    	square[16] = new BoardSquare("St. James Plance","Proprerty");
    	square[17] = new BoardSquare("Community Chest","Community Chest");
    	square[18] = new BoardSquare("Tennessee Avenue","Property");
    	square[19] = new BoardSquare("New York Avenue","Property");
    	square[20] = new BoardSquare("Free Parking","Free Parking");
    	square[21] = new BoardSquare("Kentucky Avenue","Property");
    	square[22] = new BoardSquare("Chance","Chance");
    	square[23] = new BoardSquare("Indiana Avenue","Property");
    	square[24] = new BoardSquare("Illinois Avenue","Property");
    	square[25] = new BoardSquare("B & O RailRoad","Railroad");
    	square[26] = new BoardSquare("Atlantic Avenue","Property");
    	square[27] = new BoardSquare("Ventnor Avenue","Property");
    	square[28] = new BoardSquare("Water Works","Utility");
    	square[29] = new BoardSquare("Marvin Gardnes","Property");
    	square[30] = new BoardSquare("Go to Jail","Go to Jail");
    	square[31] = new BoardSquare("Pacific Avenue","Property");
    	square[32] = new BoardSquare("North Carolina Avenue","Property");
    	square[33] = new BoardSquare("Community Chest","Community Chest");
    	square[34] = new BoardSquare("Pennsylvania Avenue","Property");
    	square[35] = new BoardSquare("Short Line","Railroad");
    	square[36] = new BoardSquare("Chance","Chance");
    	square[37] = new BoardSquare("Park Place","Property");
    	square[38] = new BoardSquare("Luxary Tax","Tax");
    	square[39] = new BoardSquare("Boardwalk","Property");   	
    	
    }
	
    public void createChanceDeck() {
    	List<String> cards = new ArrayList<>();
    	
    	cards.add("Advance to Boardwalk");
    	cards.add("Advance to Go (Collect $200)");
    	cards.add("Advance to Illinois Avenue. If you pass Go, collect $200");
    	cards.add("Advance to St. Charles Place. If you pass Go, collect $200");
    	cards.add("Advance to the nearest Railroad. If unowned, you may buy it from the Bank. If owned, pay wonder twice the rental to which they are otherwise entitled");
    	cards.add("Advance to the nearest Railroad. If unowned, you may buy it from the Bank. If owned, pay wonder twice the rental to which they are otherwise entitled");
    	cards.add("Advance token to nearest Utility. If unowned, you may buy it from the Bank. If owned, throw dice and pay owner a total ten times amount thrown.");
    	cards.add("Bank pays you dividend of $50");
    	cards.add("Get Out of Jail Free");
    	cards.add("Go Back 3 Spaces");
    	cards.add("Go to Jail. Go directly to Jail, do not pass Go, do not collect $200");
    	cards.add("Make general repairs on all your property. For each house pay $25. For each hotel pay $100");
    	cards.add("Speeding fine $15");
    	cards.add("Take a trip to Reading Railroad. If you pass Go, collect $200");
    	cards.add("You have been elected Chairman of the Board. Pay each player $50");
    	cards.add("Your building loan matures. Collect $150");
    	
    	
    	Collections.shuffle(cards);
    	
    	chanceDeck.addAll(cards);
    	
    }
    
    private void createCommunityChestDeck() {
    	List<String> cards = new ArrayList<>();
    	
    	cards.add("Advance to Go (Collect $200)");
    	cards.add("Bank error in your favor. Collect $200");
    	cards.add("Doctor’s fee. Pay $50");
    	cards.add("From sale of stock you get $50");
    	cards.add("Get Out of Jail Free");
    	cards.add("Go to Jail. Go directly to jail, do not pass Go, do not collect $200");
    	cards.add("Holiday fund matures. Receive $100");
    	cards.add("Income tax refund. Collect $20");
    	cards.add("It is your birthday. Collect $10 from every player");
    	cards.add("Life insurance matures. Collect $100");
    	cards.add("Pay hospital fees of $100");
    	cards.add("Pay school fees of $50");
    	cards.add("Receive $25 consultancy fee");
    	cards.add("You are assessed for street repair. $40 per house. $115 per hotel");
    	cards.add("You have won second prize in a beauty contest. Collect $10");
    	cards.add("You inherit $100");
    
    	
        Collections.shuffle(cards);
        
        communityDeck.addAll(cards);
    	
    	
    }
	
	

}
